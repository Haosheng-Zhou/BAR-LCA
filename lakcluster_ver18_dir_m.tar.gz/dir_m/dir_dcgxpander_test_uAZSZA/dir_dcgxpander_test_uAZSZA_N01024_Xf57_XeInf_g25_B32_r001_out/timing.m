elct = 1.34; elrt = 0.84;
