function output = fnorm(input);
output = norm(input,'fro');
