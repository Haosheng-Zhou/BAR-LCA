set(gcf,'Position',1+[0,0,1024*2,1024]);
